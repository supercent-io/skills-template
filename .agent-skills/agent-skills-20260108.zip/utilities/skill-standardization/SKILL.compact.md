# skill-standardization

> Standardize and validate SKILL.md files to match the project specification. Use when creating new skills, converting existing skills to standard fo...

## When to use this skill
• Scenario 1
• Scenario 2

## Instructions
▶ S1: [Action]
Content...
▶ S2: [Action]
Content...

## Best practices
1. Run all three scripts in sequence
2. Review changes
3. Keep section content
4. Test with one file first

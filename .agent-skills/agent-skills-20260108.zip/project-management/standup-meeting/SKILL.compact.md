# standup-meeting

> Conduct effective daily standup meetings for agile teams. Use when facilitating standups, tracking blockers, or improving team synchronization. Han...

## When to use this skill
• **매일**: 같은 시간, 같은 장소
• **스프린트 중**: 팀 동기화 필요 시
• **원격 팀**: 비동기 스탠드업

## Instructions
▶ S1: 3 Questions 포맷

## Best practices
1. Stand Up
2. Parking Lot
3. Visualize

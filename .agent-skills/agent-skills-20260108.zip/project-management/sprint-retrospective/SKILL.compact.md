# sprint-retrospective

> Facilitate effective sprint retrospectives for continuous team improvement. Use when conducting team retrospectives, identifying improvements, or f...

## When to use this skill
• **스프린트 종료**: 매 스프린트 마지막
• **프로젝트 마일스톤**: 주요 릴리스 후
• **팀 문제 발생**: 즉시 회고 필요 시

## Instructions
▶ S1: Start-Stop-Continue

## Best practices
1. Time-box
2. Rotate Facilitator
3. Celebrate Wins

# task-estimation

> Estimate software development tasks accurately using various techniques. Use when planning sprints, roadmaps, or project timelines. Handles story p...

## When to use this skill
• **Sprint Planning**: 스프린트에 포함할 작업 결정
• **Roadmap 작성**: 장기 계획 수립
• **리소스 계획**: 팀 규모 및 일정 산정

## Instructions
▶ S1: Story Points (상대적 추정)
**Fibonacci 시퀀스**: 1, 2, 3, 5, 8, 13, 21

## Best practices
1. Break Down
2. Reference Stories
3. Buffer 포함
